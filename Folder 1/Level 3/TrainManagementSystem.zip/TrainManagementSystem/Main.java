package TrainManagementSystem;

public class Main {

    public static void main(String[] args) {

        BookTrain bookTrain = new BookTrain();

        bookTrain.book('A' , 'E' , 5);
        bookTrain.book('A' , 'C' , 2);
        bookTrain.book('A' , 'C' , 1);
        bookTrain.book('D' , 'E' , 3);

        bookTrain.book('A','B',1);
        bookTrain.book('D','E',1);
        bookTrain.book('A','B',1);
        bookTrain.book('D','E',1);

        bookTrain.print();

        bookTrain.cancel(3 , 2);

        bookTrain.print();



    }
}
